package com.studentNotes.StudentsNotes.AdminEntities;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchNotesDto {
    private String email;
    private String course;
}
