package com.studentNotes.StudentsNotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsNotesApplication {
	public static void main(String[] args) {
		SpringApplication.run(StudentsNotesApplication.class, args);
	}
}

