package com.studentNotes.StudentsNotes.TeacherEntities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DownloadDto {
    private String name;
    private boolean check;
}
